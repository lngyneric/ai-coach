# Pedagogy

Authoritative source for **Teaching Prompt** design constraints — patterns, cognitive techniques, segmentation methodology, optimization methodology, and the teaching-side rules around variables, interactions, and visual-text coordination. Violating anything here generally produces a Teaching Prompt that *runs* but teaches poorly.

For format syntax / runtime constraints (which make any prompt fail to parse), see [markdownflow.md](markdownflow.md). For Course Prompt design (the course-level AI persona / style document), see [course-prompt.md](course-prompt.md).

## Script Style

A Teaching Prompt is the per-lesson MarkdownFlow document the AI engine reads at runtime — it is a *script that guides teaching*, not a polished learner-facing lecture. Write in imperative, model-guiding language.

Preferred patterns:
- "Explain to the learner …"
- "Ask the learner to …"
- "Have the learner choose …"
- "After collecting {{var}}, restate the choice and branch …"

Disallowed patterns:
- Long, polished prose written as if it is the final learner-facing lecture.
- Author/lesson-plan meta narration (e.g., "Knowledge Block …", "In this lesson you will …", "Deliverable: …").
- Author-side meta labels such as "Knowledge Block 1/2/3", "Lesson Objective", or "Deliverable" — keep those as implicit structure, not visible narration.
- Exposing internal authoring terms in learner-facing text.

## Teaching Patterns

### Pattern A: Evidence Chain

1. Observable phenomenon
2. Mechanism explanation
3. Practical implication
4. Learner interaction
5. Summary and action

### Pattern B: Misconception Repair

1. Surface common misconception
2. Explain why it sounds plausible
3. Correct with mechanism and boundary
4. Run interaction check
5. Apply corrected model to a real case

### Pattern C: Comparison-Driven Learning

1. Baseline response capture
2. Alternate scenario or constraint
3. Side-by-side interpretation
4. Updated decision path

### Pattern D: ABT Narrative (已知 → 冲突 → 为什么学)

Open every lesson with a three-beat narrative to build learner motivation (adult learners in particular), inspired by the ABT (And-But-Therefore) structure:

1. **And (已知)** — anchor on what the learner already knows or has seen.
2. **But (冲突)** — surface the gap, anomaly, or failure case that makes existing knowledge insufficient (e.g., “why does this test result mislead?”).
3. **Therefore (为什么学)** — state why resolving this conflict matters for the learner's real work.

Rules:
- The ABT open must appear before the first learning-objective statement, not after.
- The conflict beat must reference a concrete, domain-plausible case (not a generic rhetorical question).
- The “therefore” beat must tie to the learner's job outcome (decision, report, patient/customer impact).
- Keep the whole ABT open to 3-5 sentences; do not let it balloon into background lore.

### Pattern E: Five-Lens Method (五透镜法，难概念教学)

For difficult concepts (mechanisms, workflows, instrument principles), teach through five lenses instead of one long explanation:

1. **See It (看现象)** — observable outcome or symptom first.
2. **Break It (拆原理)** — decompose into parts/steps.
3. **Explain It (讲机制)** — mechanism linking parts to outcome.
4. **Compare It (对比差异)** — contrast with the nearest alternative (method, instrument, workflow).
5. **Transfer It (迁移应用)** — apply to a new but similar case.

Rules:
- Use the five-lens method when the concept has mechanism depth or high misdiagnosis risk (e.g., IVD method principles, reference-value interpretation).
- Each lens must be a distinct segment or block, not merged into one paragraph.
- The Compare lens should reuse existing comparison content from [Medical Vertical Segmentation Rules](#medical-vertical-segmentation-rules) when applicable.

## Cognitive Techniques

Increase learner understanding through targeted cognitive moves rather than information dumping. Each lesson should include at least one of these as a deepening interaction.

1. **Calibration prompt** — Ask learners to make a concrete judgment before explanation.
2. **Boundary framing** — Clarify where the concept works and where it breaks.
3. **Counterintuitive contrast** — Introduce a surprising but valid case to deepen mental models.
4. **Action translation** — Turn conceptual understanding into an immediately executable step.
5. **Reflection loop** — Ask learners to compare current understanding with prior assumptions.

## Lesson Loop

Every lesson must satisfy a minimum teaching loop and a few cross-cutting constraints:

- **Minimum teaching loop**: setup → explanation → interaction → close. A lesson missing any of these four phases is incomplete.
- **One core question per lesson**: each lesson resolves exactly one teachable question.
- **Action tasks** must be either immediately executable by the learner or explicitly linked to a downstream lesson — no orphan actions.
- **Variable naming** must be consistent and traceable across lessons (use the same name for the same concept; cross-check with [data-contracts.md#variable-table](data-contracts.md#variable-table)).
- **Source information density** must be preserved through optimization — do not trade substance for fluency.
- **Carryover statements** are allowed only when cross-lesson dependency is explicitly permitted; otherwise remove them along with any unbound carryover variables.

## Segmentation Methodology

### Objective

Produce stable lesson-oriented semantic segments from noisy source material while preserving immutable artifacts.

### Core Rules

1. Preserve source order unless explicit ordering hints are provided.
2. Keep code/image/table blocks immutable.
3. Segment by semantic shift, not heading depth alone.
4. Keep each lesson candidate centered on one teachable question.
5. Attach source spans to every segment.

### Segment Types

- `concept`: explanatory statements and definitions.
- `example`: concrete demonstrations and walkthroughs.
- `code`: executable or pseudo-code blocks.
- `image`: visual references and diagrams.
- `exercise`: learner action prompts.
- `transition`: bridge text that links ideas.

### Transfer Signals

Every segment should include transferable signals for downstream script quality:
- learner hook
- evidence type
- visual cue
- concept conflict
- boundary cue
- action cue
- density cue
- quote cue
- visual-text-pair cue
- interaction-intent cue
- compare cue

### Failure Handling

If structure is weak, output a fallback segmentation and mark uncertain spans for focused reruns.

### Medical Vertical Segmentation Rules (医学垂类分段规则)

Applies when `delivery_constraints.domain == "medical_ivd"` (IVD / 检验医学 vertical). When active, the rules below **override the generic defaults above** for the listed aspects. In a medical vertical, professional correctness outranks generic pedagogy: **a wrong reference value is a teaching incident** (错误参考值 = 教学事故).

1. **Reference-value spans are immutable.** Any segment carrying a numeric reference range, unit, or normal value is marked `preserve_block: true` and tagged `immutable` in its transfer signals. Never paraphrase, round, or "simplify" a reference range; keep number, unit, and exponent verbatim. Examples that MUST stay exact:
   - `RBC 4.5–5.5×10¹²/L`
   - `WBC 4.0–10.0×10⁹/L`
   - `PLT 125–350×10⁹/L`

2. **Terminology unification table.** Use only the authoritative names below for medical-vertical segments; **synonym substitution is forbidden** (e.g. do not write "红血球" for RBC, or "血红蛋白量" for HGB). If the knowledge-graph lookup (`scripts/ivd-lookup.py`) returns a different canonical term, the graph wins.

   | 中文全称 | 缩写 | English full name |
   |---|---|---|
   | 红细胞计数 | RBC | Red Blood Cell Count |
   | 白细胞计数 | WBC | White Blood Cell Count |
   | 血小板计数 | PLT | Platelet Count |
   | 血红蛋白 | HGB | Hemoglobin |
   | 血细胞比容 | HCT | Hematocrit |
   | 平均红细胞体积 | MCV | Mean Corpuscular Volume |
   | 网织红细胞 | RET | Reticulocyte |
   | 凝血酶原时间 | PT | Prothrombin Time |
   | 活化部分凝血活酶时间 | APTT | Activated Partial Thromboplastin Time |
   | 纤维蛋白原 | FIB | Fibrinogen |
   | 国际标准化比值 | INR | International Normalized Ratio |
   | D-二聚体 | D-Dimer | D-Dimer |
   | 尿比重 | SG | Specific Gravity |

3. **Segment by test system, not by mental model.** Split along the six IVD systems — 血液 (hematology) / 凝血 (coagulation) / 尿液 (urinalysis) / 免疫 (immunoassay) / 生化 (biochemistry) / 分子 (molecular) — **before** applying any generic semantic-shift logic. A hematology concept must not be merged into a coagulation lesson even if the narrative flows that way; system membership is resolved from the knowledge graph, not from prose.

4. **Segmentation unit = knowledge ontology / test item.** Each lesson candidate resolves exactly **one assessable knowledge point**: one test item (e.g. "WBC 五分类的计数原理") or one sub-concept of a test item. The core question must be answerable in a graded form, not open-ended reflection.

5. **Zero error tolerance + gradeable acceptance items.** Every reference value, unit, and term must be verifiable. Map each lesson's acceptance to a gradeable item and carry it in the segment's transfer signals:
   - `exam` — recall a reference value / unit / terminology;
   - `review` — interpret a given result (e.g. given a CBC report, judge it normal or abnormal);
   - `practice` — apply to a case (e.g. compute or categorize from given values).
   Reject any lesson whose core point cannot be assessed in at least one of these three forms.

6. **Mandatory knowledge-graph lookup before segmentation.** Run `python3 scripts/ivd-lookup.py "<检验项目/系统/术语>"` to confirm terminology, reference values, and system membership **before** segmenting. See `references/ivd-knowledge.md` for usage and the built-in reference-value table. Fallback: if the graph has no entry for a span, mark the span `uncertain` (high), keep the source wording verbatim, and flag it for human confirmation — **never invent a reference value or unit**.

## Optimization Methodology

### Principles

1. Correctness before style.
2. Minimal safe edits before broad rewrites.
3. Learner impact before formatting polish.
4. Traceable changes with explicit rationale.

### Issue Taxonomy

- Coverage gap
- Meaning shift
- Explanation clarity
- Interaction no-branching
- Visual requirement missing
- Variable or syntax risk

### Execution Sequence

1. Build source-to-script coverage matrix.
2. Rank issues by learner risk and runtime risk.
3. Fix blockers first.
4. Revalidate variable lifecycle and interaction effects.
5. Run final syntax and density checks.

## Variable Strategy

These are the *teaching* rules around variables — when to collect, how often, how to ensure they matter. For variable *syntax* see [markdownflow.md#variables](markdownflow.md#variables); for variable *schema* see [data-contracts.md#variable-table](data-contracts.md#variable-table).

- Prefer at most one variable collection per module; distribute, don't front-load.
- Max five interactions per lesson (recommended three to four).
- No more than three consecutive variable collections before learner-visible feedback.
- Reuse global variables when possible; add lesson-local variables only when required.
- Every variable must have downstream utility (branching, depth control, or deliverable variation).
- Do not recollect the same variable unless explicitly marked as staged comparison.
- Prevent semantic duplicates even when variable names differ.
- Spread global variable collection across lessons.

## Interaction Design

These are the *teaching* rules around interactions. For interaction *syntax* see [markdownflow.md#interactions](markdownflow.md#interactions).

- Each lesson includes at least one deepening interaction (calibration, boundary check, or misconception correction — see [Cognitive Techniques](#cognitive-techniques)).
- Interaction prompts must be concrete and directly answerable.
- Place interactions at decision points, not only at lesson start.
- Every interaction must trigger immediate feedback **and** a visible downstream effect (branching explanation, examples, practice difficulty, feedback).
- After every interaction, restate the learner's selection explicitly as an instruction (e.g., `Restate the learner's current choice as {{var}}.`), not as polished narration.
- `*_viewpoint_check` interactions must branch by option and drive different next steps.
- Use no more than one `viewpoint_check` per lesson unless justified.
- Avoid repetitive interaction semantics across lessons unless comparison intent is explicit.
- For input interactions, the pre-interaction question must be more specific than the short `...` placeholder.

### Scaffolded Difficulty (三层脚手架)

Layer practice difficulty so learners can attempt increasingly independent work (inspired by I do / We do / You do):

1. **Full demonstration** — worked example with every step shown.
2. **Partial prompt** — same task with hints; learner fills the gap.
3. **Independent attempt** — no hints; learner completes from scratch.

Rules:
- Use scaffolding when a lesson contains practice of a multi-step skill (interpretation, workflow, response drafting).
- At most one full scaffolded sequence per lesson; avoid repeating identical drill levels.
- The independent attempt must be followed by an interaction with real feedback, not a dead-end question.
- Scaffold depth should be explicit in the Teaching Prompt (e.g., `Provide a worked example first, then a hinted attempt, then an independent attempt.`).

### Diagnostic Feedback (错误诊断反馈)

Every wrong option must carry a concrete diagnosis, not a bare “wrong” label:

- For each incorrect choice, state why it sounds plausible and why it is wrong (mechanism, boundary, or missing step).
- After a wrong selection, branch into a short correction explanation before re-asking, instead of looping the same prompt.
- Diagnoses must be domain-accurate — reuse the terminology from [Medical Vertical Segmentation Rules](#medical-vertical-segmentation-rules) and the reference tables in `ivd-lookup.py` when available.
- Never attribute an error to learner carelessness; attribute it to a specific concept gap.
- If an interaction has multiple distractors, each distractor needs its own one-line diagnosis in the branch or feedback copy.

## Visual-Text Coordination

- If a visual is needed, describe it in natural language (e.g., "Show an image that …").
- Pair every visual instruction with a brief explanation of what the visual is meant to convey.
- Do not embed raw SVG/HTML/Mermaid/PlantUML/Graphviz markup inside Teaching Prompts unless the user explicitly asks for that format.
- Default to natural-language image/diagram placeholders.
- Every core concept needs visual + textual explanation together; the visual carries structural prompting, the text carries the full explanation (assume the learner has not seen the image).
